using SiliconStudio.Xenko.Engine;

namespace ParticlesSpotlight1
{
    class ParticlesSpotlight1App
    {
        static void Main(string[] args)
        {
            using (var game = new Game())
            {
                game.Run();
            }
        }
    }
}
