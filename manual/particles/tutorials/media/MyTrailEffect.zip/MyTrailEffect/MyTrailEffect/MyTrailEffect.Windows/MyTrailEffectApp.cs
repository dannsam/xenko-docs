using SiliconStudio.Xenko.Engine;

namespace MyTrailEffect
{
    class MyTrailEffectApp
    {
        static void Main(string[] args)
        {
            using (var game = new Game())
            {
                game.Run();
            }
        }
    }
}
